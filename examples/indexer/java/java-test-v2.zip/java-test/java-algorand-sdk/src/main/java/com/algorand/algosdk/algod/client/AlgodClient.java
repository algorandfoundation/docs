package com.algorand.algosdk.algod.client;

public class AlgodClient extends ApiClient {
}
