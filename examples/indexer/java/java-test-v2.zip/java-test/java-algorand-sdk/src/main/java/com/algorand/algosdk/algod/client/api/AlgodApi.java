package com.algorand.algosdk.algod.client.api;

import com.algorand.algosdk.algod.client.AlgodClient;
import com.algorand.algosdk.algod.client.ApiClient;
import com.algorand.algosdk.algod.client.Configuration;

public class AlgodApi extends DefaultApi {

    public AlgodApi() {
        super();
    }

    public AlgodApi(ApiClient apiClient) {
        super(apiClient);
    }

}
