package com.algorand.algosdk.kmd.client;

public class KmdClient extends ApiClient {
}
